package com.ssafy.happyhouse.model;

public class Shop {
	String shopNo, shopName, shopClass, shopSido, shopDong, shopGungu, shopAddress, shopPostalCode;

	public String getShopNo() { return shopNo; }
	public void setShopNo(String shopNo) { this.shopNo = shopNo; }

	public String getShopGungu() { return shopGungu; }
	public void setShopGungu(String shopGungu) { this.shopGungu = shopGungu; }
	
	public String getShopName() { return shopName; }
	public void setShopName(String shopName) { this.shopName = shopName; }

	public String getShopClass() { return shopClass; }
	public void setShopClass(String shopClass) { this.shopClass = shopClass; }

	public String getShopSido() { return shopSido; }
	public void setShopSido(String shopSido) { this.shopSido = shopSido; }

	public String getShopDong() { return shopDong; }
	public void setShopDong(String shopDong) { this.shopDong = shopDong; }

	public String getShopAddress() { return shopAddress; }
	public void setShopAddress(String shopAddress) { this.shopAddress = shopAddress; }

	public String getShopPostalCode() { return shopPostalCode; }
	public void setShopPostalCode(String shopPostalCode) { this.shopPostalCode = shopPostalCode; }
}
