package com.ssafy.happyhouse.model;

public class AptDeal {
	private int no;
    private String dong;
    private String aptname;
    private String code;
    private String dealamount;
    private String buildyear;
    private String dealyear;
    private String dealmonth;
    private String dealday;
    private String area;
    private String floor;
    private String jibun;
    private String type;
    private String rentmoney;


    public void setNo(int no) { 
        this.no = no;
    }

    public int getNo() { 
        return no;
    }

    public void setDong(String dong) { 
        this.dong = dong;
    }

    public String getDong() { 
        return dong;
    }

    public void setAptname(String aptname) { 
        this.aptname = aptname;
    }

    public String getAptname() { 
        return aptname;
    }

    public void setCode(String code) { 
        this.code = code;
    }

    public String getCode() { 
        return code;
    }

    public void setDealamount(String dealamount) { 
        this.dealamount = dealamount;
    }

    public String getDealamount() { 
        return dealamount;
    }

    public void setBuildyear(String buildyear) { 
        this.buildyear = buildyear;
    }

    public String getBuildyear() { 
        return buildyear;
    }

    public void setDealyear(String dealyear) { 
        this.dealyear = dealyear;
    }

    public String getDealyear() { 
        return dealyear;
    }

    public void setDealmonth(String dealmonth) { 
        this.dealmonth = dealmonth;
    }

    public String getDealmonth() { 
        return dealmonth;
    }

    public void setDealday(String dealday) { 
        this.dealday = dealday;
    }

    public String getDealday() { 
        return dealday;
    }

    public void setArea(String area) { 
        this.area = area;
    }

    public String getArea() { 
        return area;
    }

    public void setFloor(String floor) { 
        this.floor = floor;
    }

    public String getFloor() { 
        return floor;
    }

    public void setJibun(String jibun) { 
        this.jibun = jibun;
    }

    public String getJibun() { 
        return jibun;
    }

    public void setType(String type) { 
        this.type = type;
    }

    public String getType() { 
        return type;
    }

    public void setRentmoney(String rentmoney) { 
        this.rentmoney = rentmoney;
    }

    public String getRentmoney() { 
        return rentmoney;
    }
}
